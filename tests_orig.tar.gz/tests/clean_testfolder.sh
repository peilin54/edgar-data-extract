#!/bin/bash


# clean up before running
rm -v test-1/*.csv 
rm -v test-1/test_data/*.mod

rm -v test-100/*.csv 
rm -v test-100/test_data/*.mod

rm -v test-jup/test_data/*.csv 
rm -v test-jup/test_data/*.mod
